package com.example.service_call

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.service_call.DataClass.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.Objects


class MainActivity : AppCompatActivity() {
    lateinit var adapter:Adaptor
    lateinit var textView:TextView

    lateinit var recyclerView: RecyclerView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        textView=findViewById(R.id.textView)
        recyclerView=findViewById(R.id.recycler_view)
        recyclerView.layoutManager=LinearLayoutManager(this)
        adapter= Adaptor(emptyList())
        recyclerView.adapter=adapter
        getData()
        postMethod();
        update()
        deleteMethod()
    }

    private fun deleteMethod() {
        try {

            val refroDelete=RetrofitClient.retrofit.getDelete()
            refroDelete.enqueue(object :Callback<DeleteModel>{
                override fun onResponse(call: Call<DeleteModel>, response: Response<DeleteModel>) {
                    Log.d("delete_response","=====>"+response.body())
                    Toast.makeText(this@MainActivity,""+response.body(),Toast.LENGTH_SHORT).show()
                }

                override fun onFailure(call: Call<DeleteModel>, t: Throwable) {
                }
            })
        }catch (e:Exception){
            e.stackTrace
        }

    }

    private fun update() {
        try {
            val retrofitClient=RetrofitClient.retrofit.getUpdate()
            retrofitClient.enqueue(object :Callback<Todo>{
                override fun onResponse(call: Call<Todo>, response: Response<Todo>) {
                    if (response.isSuccessful){
                        Log.d("data","uuu"+response.body())
                        Toast.makeText(this@MainActivity,""+response.body(),Toast.LENGTH_SHORT).show()

                    }
                }

                override fun onFailure(call: Call<Todo>, t: Throwable) {
                }
            })

        }catch (e:Exception){
            e.stackTrace
        }
    }


    private fun postMethod() {

        // Make the POST Request
        GlobalScope.launch(Dispatchers.Main) {
            try {
                val response = RetrofitClient.retrofit.addTodo(Todo(1, "data", false, 5))
              //  val response = todoRepository.addTodo(Todo(1, "data", false, 5))
                // Use response to display the todo item
                // For example:
                Log.d("this","gggg"+response)
                textView.text = "ID: ${response.id}, Todo: ${response.todo}, Completed: ${response.completed}, User ID: ${response.userId}"
            } catch (e: Exception) {
                // Handle error
                Log.e("MainActivity", "Error: ${e.message}")
            }
        }
    }




    private fun getData() {
        val retrofitClient=RetrofitClient.retrofit.getTodos()
        retrofitClient.enqueue(object :retrofit2.Callback<TodoResponse>{
            override fun onResponse(call: Call<TodoResponse>, response: Response<TodoResponse>) {
                    if(response.isSuccessful){
                        val todolist=response.body()?.todos?: emptyList()
                        adapter= Adaptor(todolist )
                        recyclerView.adapter=adapter
                    }

            }

            override fun onFailure(call: Call<TodoResponse>, t: Throwable) {
            }
        }

        )
    }
/*
    private fun postMethod() {
       // val request=Model(151, "Use DummyJSON in the project", false, 5)
        val retrofitclient=RetrofitClient.retrofit.createTodo(1,"data",false,12)
       // Log.d("response","---"+request)

        retrofitclient.enqueue(object : Callback<ResponseModel>{
            override fun onResponse(call: Call<ResponseModel>, response: Response<ResponseModel>) {
                Log.d("response","---"+response)

                if (response.isSuccessful){
                    Log.d("response","---"+response)
                }else{
                    Toast.makeText(this@MainActivity,"error response",Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<ResponseModel>, t: Throwable) {
            }

        },)

    }
*/

}
