package com.example.service_call

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.service_call.DataClass.Todo

class Adaptor(private val todolist:List<Todo>) :RecyclerView.Adapter<Adaptor.ViewHolder>(){

    @SuppressLint("SuspiciousIndentation")
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
     val  view=LayoutInflater.from(parent.context).inflate(R.layout.list,parent,false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val tododata =todolist[position]
        holder.id.text= tododata.id.toString()
        holder.todo.text = tododata.todo
        holder.completed.text = tododata.completed.toString()
        holder.userId.text = tododata.userId.toString()


    }

    override fun getItemCount(): Int {
        return todolist.size
    }

class ViewHolder(itemView: View):RecyclerView.ViewHolder(itemView) {
     val id: TextView = itemView.findViewById(R.id.id)
     val todo: TextView = itemView.findViewById(R.id.todo)
     val completed: TextView = itemView.findViewById(R.id.completed)
     val userId: TextView = itemView.findViewById(R.id.userId)

}
}
