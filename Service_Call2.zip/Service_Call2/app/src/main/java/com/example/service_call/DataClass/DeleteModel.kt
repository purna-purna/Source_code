package com.example.service_call.DataClass

data class DeleteModel(val id: Int,
                       val todo: String,
                       val completed: Boolean,
                       val userId: Int,
                       val isDeleted: Boolean,
                       val deletedOn: String)
