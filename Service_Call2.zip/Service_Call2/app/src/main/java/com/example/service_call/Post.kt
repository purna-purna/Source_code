package com.example.service_call

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class Post : AppCompatActivity() {
    lateinit var editText1:EditText
    lateinit var editText2:EditText
    lateinit var editText3:EditText
    lateinit var calculateButton:Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_post)
         editText1 = findViewById<EditText>(R.id.editText1)
         editText2 = findViewById<EditText>(R.id.editText2)
         editText3 = findViewById<EditText>(R.id.editText3)
         calculateButton = findViewById<Button>(R.id.calculateButton)
        val resultTextView = findViewById<TextView>(R.id.resultTextView)

        calculateButton.setOnClickListener(View.OnClickListener {
            if (editText1.text.toString().length==0){
                Toast.makeText(this,"Please Enter InputTextfield1",Toast.LENGTH_SHORT).show()
            }else if (editText2.text.toString().length==0){
                Toast.makeText(this,"Please Enter InputTextfield2",Toast.LENGTH_SHORT).show()
            }else if (editText3.text.toString().length==0){
                Toast.makeText(this,"Please Enter InputTextfield3",Toast.LENGTH_SHORT).show()
            }else{
                val input1 = editText1.text.toString().split(",").map { it.trim().toInt() }.toSet()
                val input2 = editText2.text.toString().split(",").map { it.trim().toInt() }.toSet()
                val input3 = editText3.text.toString().split(",").map { it.trim().toInt() }.toSet()

                val intersection = input1.intersect(input2).intersect(input3)
                val union = input1.union(input2).union(input3)
                val highest = setOf(input1.max(), input2.max(), input3.max()).max()

                resultTextView.text = "Intersection: $intersection\nUnion: $union\nHighest: $highest"
            }
        })
    }
}