package com.example.service_call.DataClass

data class TodoResponse(
    val total: Int,
    val skip: Int,
    val limit: Int,
    val todos: List<Todo>)



