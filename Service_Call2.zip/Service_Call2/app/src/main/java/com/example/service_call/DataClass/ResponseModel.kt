package com.example.service_call.DataClass

data class ResponseModel(
    val id:Int,
    val todo:String,
    val completed:Boolean,
    val userID:Int

)
